package com.example.pizzaa

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.BaseAdapter
import android.widget.ImageView
import android.widget.TextView

class PizzaAdapter(
    private val context: MainActivity,
    private val nombres: List<String>,
    private val imagenes: List<Int>
) : BaseAdapter() {

    override fun getCount(): Int = nombres.size

    override fun getItem(position: Int): Any = nombres[position]

    override fun getItemId(position: Int): Long = position.toLong()

    override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
        val view: View
        val holder: ViewHolder

        if (convertView == null) {
            // Inflar el layout para cada ítem
            view = LayoutInflater.from(context).inflate(R.layout.item_pizza, parent, false)
            holder = ViewHolder()
            holder.imagenPizza = view.findViewById(R.id.imagenPizza)
            holder.nombrePizza = view.findViewById(R.id.nombrePizza)
            view.tag = holder
        } else {
            view = convertView
            holder = view.tag as ViewHolder
        }

        // Asignar los datos
        holder.imagenPizza?.setImageResource(imagenes[position])
        holder.nombrePizza?.text = nombres[position]

        return view
    }

    private class ViewHolder {
        var imagenPizza: ImageView? = null
        var nombrePizza: TextView? = null
    }
}