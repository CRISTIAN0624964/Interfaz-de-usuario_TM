package com.example.pizzaa

import android.os.Bundle
import android.widget.GridView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    private lateinit var gridViewPizzas: GridView

    // Lista de nombres de pizzas
    private val nombresPizzas = listOf(
        "Margherita",
        "Pepperoni",
        "Hawaiana",
        "Cuatro Quesos",
        "BBQ",
        "Vegetariana",
        "Napolitana",
        "Diavola",
        "Funghi"
    )

    // Lista de imágenes con los nuevos nombres
    private val imagenesPizzas = listOf(
        R.drawable.pizza_1,
        R.drawable.pizza_2,
        R.drawable.pizza_3,
        R.drawable.pizza_4,
        R.drawable.pizza_5,
        R.drawable.pizza_6,
        R.drawable.pizza_7,
        R.drawable.pizza_8,
        R.drawable.pizza_9
    )

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        gridViewPizzas = findViewById(R.id.gridViewPizzas)

        val adapter = PizzaAdapter(this, nombresPizzas, imagenesPizzas)
        gridViewPizzas.adapter = adapter

        gridViewPizzas.setOnItemClickListener { _, _, position, _ ->
            val nombre = nombresPizzas[position]
            Toast.makeText(this, "🍕 Pizza: $nombre", Toast.LENGTH_SHORT).show()
        }
    }
}